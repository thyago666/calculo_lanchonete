<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <?php if(isset($acessorios)): ?>
    <form method="post" action="<?php echo e(url("/update/acessorios/$acessorios->id")); ?>">
        <?php endif; ?>
        <?php if(!isset($acessorios)): ?>
        <form method="post" action="<?php echo e(url('/insert/acessorios')); ?>">
            <?php endif; ?>
      <?php echo csrf_field(); ?>
          <div class="form-group">
          <label for="descricao"><b>Descrição</b></label>
          <?php if(isset($acessorios)): ?>

          <input type="text" class="form-control" id="descricao" name="descricao"
           value="<?php echo e($acessorios->descricao); ?>" >
           <?php else: ?>
           <input type="text" class="form-control" id="descricao" name="descricao">
           <?php endif; ?>
       
          <small id="descricao" class="form-text text-muted">Informe aqui a descrição de seu acessório, ex: Sacolinha, Vasilha Isopor 500gr, Papel Embrulho etc</small>
        </div>

      
        
        <button type="submit" class="btn btn-primary">Gravar</button>
        <a href="<?php echo e(url("/")); ?>"> <button type="button" class="btn btn-warning">Voltar</button></a>

      </form>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\calculo\resources\views/cadAcessorioView.blade.php ENDPATH**/ ?>