<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <div class="container">
      
      <H2>CADASTRO DE PRODUTOS</H2>
      <br>  <br>
      <a href="<?php echo e(url("/cadastro/produtos")); ?>"> <button type="button" class="btn btn-success">+ Incluir Produtos</button></a>
     <a href="<?php echo e(url("/")); ?>"> <button type="button" class="btn btn-warning">Voltar</button></a>
     <br>  <br>
    <table class="table">
        <thead>
          <tr align="center">
 
            <th scope="col">Descrição</th>
            <th scope="col">Tipo</th>
            <th scope="col">Inserir</th>
            <th scope="col">Opções</th>
      
          </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr align="center">
            <td><?php echo e($produto->descricao); ?></td>
            <td><?php echo e($produto->tipo); ?></td>
            <td>
              <a href="<?php echo e(url("/cadastro/item/$produto->id")); ?>"><button type="button" class="btn btn-info">Ingredientes</button></a>
              <a href="<?php echo e(url("/cadastro/item-acessorio/$produto->id")); ?>"><button type="button" class="btn btn-secondary">Acessórios</button></a>
           </td>
              <td>
         <a href="<?php echo e(url("/alterar/produto/$produto->id")); ?>"><button type="button" class="btn btn-primary">Alterar</button></a>
<input type="hidden" value="<?php echo e($produto->id); ?>" id="id">
<button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#produto_<?php echo e($produto->id); ?>">
Excluir
</button>

<?php echo $__env->make('confirmaDelete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>       
            </td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH C:\xampp\htdocs\calculo\resources\views/produtosView.blade.php ENDPATH**/ ?>