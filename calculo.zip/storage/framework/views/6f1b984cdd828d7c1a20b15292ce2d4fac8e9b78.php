<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>

    <div class="container">
      <h2>CADASTRO DE INGREDIENTES</h2>
      <br>
      <a href="<?php echo e(url("/cadastro/ingrediente")); ?>"> <button type="button" class="btn btn-success">+ Incluir</button></a>
      <a href="<?php echo e(url("/")); ?>"> <button type="button" class="btn btn-warning">Voltar</button></a>
      <br>      <br> 
    <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Descrição</th>
            <th scope="col">Unidade de Medida</th>
            <th scope="col">Valor</th>
            <th scope="col">Opções</th>
          </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $ingredientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingrediente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row"><?php echo e($ingrediente->id); ?></th>
            <td><?php echo e($ingrediente->descricao); ?></td>
            <td><?php echo e($ingrediente->unidMedida); ?></td>
   
            <td><?php echo e('R$ '.number_format($ingrediente->valor, 2, ',', '.')); ?></td>
 
                <td>
        <a href="<?php echo e(url("/edit/ingrediente/$ingrediente->id")); ?>"><button type="button" class="btn btn-primary">Alterar</button></a>
                  </td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
   
        </tbody>
      </table>

    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\calculo\resources\views/viewIngrediente.blade.php ENDPATH**/ ?>