<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php
    $lastDescProd = null;
    $total_ingredientes = 0;
    $desc = null;
    $total_acessorio = 0;
  
?>


<?php for($i=1; $i <= $countProdutos*2; $i++): ?>

    <?php $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<?php if($item->idProd == $i): ?>

            <?php if($lastDescProd !== $item->desc_prod): ?>
            <hr>
                <p><b><?php echo e($item->desc_prod); ?></b></p>
                <?php
                    $lastDescProd = $item->desc_prod;
                ?>
            <?php endif; ?>

              <?php echo e($item->descricaoSimples); ?>,

            <?php if($item->unidMedida == 'kilo'): ?>
                <?php
                    $resul = ($item->valor*$item->qtd)/1000;
                    $total_ingredientes = $total_ingredientes + $resul;
                ?>
            <?php endif; ?>

            <?php if($item->unidMedida == 'litro'): ?>
                <?php
                    $resul = ($item->valor*$item->qtd)/900;
                    $total_ingredientes = $total_ingredientes + $resul;
                ?>
            <?php endif; ?>

            <?php if($item->unidMedida == 'porcao'): ?>
                <?php
                    $valor_cada_porcao = ($item->valor/$item->qtd_porcao);
                    $resul = ($valor_cada_porcao*$item->qtd);
                    $total_ingredientes = $total_ingredientes + $resul;
                ?>
            <?php endif; ?>

            <?php if($item->unidMedida == 'unidade'): ?>
                <?php
                    $resul = ($item->valor*$item->qtd);
                    $total_ingredientes = $total_ingredientes + $resul;
                ?>
            <?php endif; ?>
   
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


 
        <?php $__currentLoopData = $acessorios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acessorio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($acessorio->idProd == $i): ?>
    
            <?php
                $total_acessorio = ($total_acessorio+$acessorio->valor*$acessorio->qtd_itens);
            ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  

    <?php if($total_ingredientes != 0 or $total_acessorio != 0): ?>
    <br><br>
    <b>  Valor: <?php echo e('R$ '.number_format(($total_ingredientes+$total_acessorio)*2, 2, ',', '.')); ?></b>
    <?php
    $total_ingredientes = 0;
    $total_acessorio = 0;
    ?>
    <?php endif; ?>
    
<?php endfor; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\calculo\resources\views/viewCardapio.blade.php ENDPATH**/ ?>