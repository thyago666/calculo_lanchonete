<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<div class="container">
    <h1><?php echo e($produto->descricao); ?></h1>
    <form method="post" action="<?php echo e(url('/insert/item-acessorio/')); ?>">
        <?php echo csrf_field(); ?>

        <input type="hidden" class="form-control" value=<?php echo e($produto->id); ?> id="produto" name="produto">

    <div class="form-group">
        <label for="acessorio"><b>Acessórios</b></label>
        <select class="form-control" id="acessorios" name="acessorios">
            <?php $__currentLoopData = $acessorios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acessorio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value=<?php echo e($acessorio->id); ?>><?php echo e($acessorio->descricao); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
   
          </select>
      </div>
      <div class="form-group">
        <label for="descricao"><b>Qtd</b></label>
        <input type="number" class="form-control" id="qtd" name="qtd">
        <small id="qtd" class="form-text text-muted">Informe aqui a quantidade que vai 
            desse acessório</small>
      </div>
      <button type="submit" class="btn btn-primary">Inserir</button>

      <a href="<?php echo e(url("/")); ?>"> <button type="button" class="btn btn-warning">Voltar</button></a>





    </form><br>
    
      
    <br>
    <form method="post" action="<?php echo e(url('/insert/importacao/')); ?>">
      <?php echo csrf_field(); ?>
      <input type="hidden" class="form-control" value=<?php echo e($produto->id); ?> id="produto" name="produto">
    <div class="form-group">
      <label for="exampleFormControlSelect1"><b>Selecione o lanche para importação</b></label>
      <select class="" id="id_lanche" name="selectLanche">
          <?php $__currentLoopData = $importar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option id="<?php echo e($imps->id); ?>" value="<?php echo e($imps->id); ?>"><?php echo e($imps->descricao); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      <button type="submit" class="btn btn-warning">Importar</button></a>
    </div>
    </form>


    <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Descrição</th>
            <th scope="col">Qtd</th>
            <th scope="col">Valor</th>
            <th scope="col">Opções</th>
        
          </tr>
        </thead>
        <tbody>


            <?php $__currentLoopData = $itens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <tr>
            <th scope="row"><?php echo e($item->id); ?></th>
            <td><?php echo e($item->descricao); ?></td>
            <td><?php echo e($item->qtd); ?></td>
            <td><?php echo e('R$ '.number_format($item->vl_unit*$item->qtd, 2, ',', '.')); ?></td>
           <td> <a href="<?php echo e(url("/delete/item-acessorio/$item->id_item/$item->id_produto")); ?>"><button type="button" class="btn btn-danger">Excluir</button></a></td>
          </tr>
     
          
 
            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\calculo\resources\views/cadItemAcessorio.blade.php ENDPATH**/ ?>