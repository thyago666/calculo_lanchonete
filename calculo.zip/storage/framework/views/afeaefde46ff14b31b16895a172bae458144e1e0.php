<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<div class="container">
    <h1><?php echo e($produto->descricao); ?></h1>
    <form method="post" action="<?php echo e(url('/insert/item/')); ?>">
        <?php echo csrf_field(); ?>

        <input type="hidden" class="form-control" value=<?php echo e($produto->id); ?> id="produto" name="produto">

    <div class="form-group">
        <label for="unidade_medida"><b>Ingredientes</b></label>
        <select class="form-control" id="ingredientes" name="ingredientes">
            <?php $__currentLoopData = $ingredientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingrediente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option  value=<?php echo e($ingrediente->id); ?>><?php echo e($ingrediente->descricao); ?> - <?php echo e($ingrediente->unidMedida); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
        </select>
      </div>
      <div class="form-group">
        <label for="descricao"><b>Qtd</b></label>
        <input type="number" class="form-control" id="qtd" name="qtd">
        <small id="qtd" class="form-text text-muted">Informe aqui a quantidade que vai 
            desse ingrediente nesse lanche, geralmente essa quantidade é em grama, unidade ou porção</small>
      </div>
      <button type="submit" class="btn btn-primary">Inserir</button>

      <a href="<?php echo e(url("/")); ?>"> <button type="button" class="btn btn-warning">Voltar</button></a>
    </form><br>
    <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Descrição</th>
            <th scope="col">Medida</th>
            <th scope="col">Qtd</th>
            <th scope="col">Custo Total</th>
            <th scope="col">Opções</th>
        
          </tr>
        </thead>
        <tbody>
          <?php
  
  $resul = 0;
  $total = 0;
  $valor_cada_porcao = 0;
  ?>
  
            <?php $__currentLoopData = $itens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <tr>
            <th scope="row"><?php echo e($item->id); ?></th>
            <td><?php echo e($item->descricao); ?></td>
            <td><?php echo e($item->unidMedida); ?></td>
            <td><?php echo e($item->qtd); ?></td>

    <?php if($item->unidMedida == 'kilo'): ?>
     <?php
        $resul = ($item->valor*$item->qtd)/1000;
     ?>
     <td><?php echo e('R$ '.number_format($resul, 2, ',', '.')); ?></td>
    <?php endif; ?>

    <?php if($item->unidMedida == 'unidade'): ?>
      <?php
       $resul = ($item->valor*$item->qtd);
      ?>
     <td><?php echo e('R$ '.number_format($resul, 2, ',', '.')); ?></td>
    <?php endif; ?>

    <?php if($item->unidMedida == 'porcao'): ?>
    <?php
      $valor_cada_porcao = ($item->valor/$item->qtd_porcao);
      $resul = ($valor_cada_porcao*$item->qtd);
    ?>
     <td><?php echo e('R$ '.number_format($resul, 2, ',', '.')); ?></td>
    <?php endif; ?>

    <?php if($item->unidMedida == 'litro'): ?>
      <?php
        $resul = ($item->valor*$item->qtd)/900;
      ?>
     <td><?php echo e('R$ '.number_format($resul, 2, ',', '.')); ?></td>
    <?php endif; ?>


        <td>
           <a href="<?php echo e(url("/delete/item/$item->id_item/$item->id_produto")); ?>"><button type="button" class="btn btn-danger">Excluir</button></a>
          
           
            </td>
            </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\calculo\resources\views/cadItem.blade.php ENDPATH**/ ?>