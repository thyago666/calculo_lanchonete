<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
    <form method="post" action="<?php echo e(url('/pesquisa')); ?>">
        <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="exampleFormControlSelect1"><b>Selecione o lanche para pesquisa</b></label>
        <select class="form-control" id="id_lanche" name="selectLanche">
            <?php $__currentLoopData = $lanches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lanche): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option id="<?php echo e($lanche->id); ?>" value="<?php echo e($lanche->descricao); ?>"><?php echo e($lanche->descricao); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
      </div>
      <button type="submit" class="btn btn-primary">Pesquisar</button>
      <a href="<?php echo e(url("/")); ?>"> <button type="button" class="btn btn-warning">Voltar</button></a>
    </form><br>

    <div align="center">
        <h1><?php echo e($psq); ?></h1>
    </div>

    <?php
    $resul = 0;
  $total_ingredientes = 0;
  $total_acessorio=0;
 // $tot_acessorios=0;
  ?>

    <table class="table">
        <thead class="thead-dark">
          <tr>
           <th>Ingredientes</th>
           <th>Medida</th>
           <th>Qtd</th>
            <th>Valor Custo Total</th>
           </tr>
        </thead>
        <tbody>
          
            <?php $__currentLoopData = $ingredientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingrediente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($ingrediente->desc_prod == $psq): ?>
          <tr>
         <td><?php echo e($ingrediente->ing_descricao); ?></td>
         <td><?php echo e($ingrediente->unidMedida); ?></td>
         <td><?php echo e($ingrediente->qtd); ?></td>

     <?php if($ingrediente->unidMedida == 'kilo' && $ingrediente->desc_prod == $psq): ?>
   <?php
        $resul = ($ingrediente->valor*$ingrediente->qtd)/1000;
        $total_ingredientes = $total_ingredientes + $resul;
     ?>
        <td><?php echo e('R$ '.number_format($resul, 2, ',', '.')); ?></td>
    <?php endif; ?>

    <?php if($ingrediente->unidMedida == 'litro' && $ingrediente->desc_prod == $psq): ?>
   <?php
        $resul = ($ingrediente->valor*$ingrediente->qtd)/900;
        $total_ingredientes = $total_ingredientes + $resul;
     ?>
        <td><?php echo e('R$ '.number_format($resul, 2, ',', '.')); ?></td>
    <?php endif; ?>

    <?php if($ingrediente->unidMedida == 'porcao' && $ingrediente->desc_prod == $psq): ?>
    <?php
         $valor_cada_porcao = ($ingrediente->valor/$ingrediente->qtd_porcao);
         $resul = ($valor_cada_porcao*$ingrediente->qtd);
         $total_ingredientes = $total_ingredientes + $resul;

       ?>
             <td><?php echo e('R$ '.number_format($resul, 2, ',', '.')); ?></td>
        <?php endif; ?>


       <?php if($ingrediente->unidMedida == 'unidade' && $ingrediente->desc_prod == $psq): ?>
        <?php
         $resul = ($ingrediente->valor*$ingrediente->qtd);
         $total_ingredientes = $total_ingredientes + $resul;
      ?>
             <td><?php echo e('R$ '.number_format($resul, 2, ',', '.')); ?></td>
         <?php endif; ?>
         </tr>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>

  
    <table class="table">
        <thead class="thead-dark">
          <tr>
           <th>Acessórios</th>
           <th>QTD</th>
            <th>Valor Custo</th>
           </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $acessorios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acessorio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($acessorio->desc_prod == $psq): ?>
          <tr>
         <td><?php echo e($acessorio->ace_descricao); ?></td>
         <td><?php echo e($acessorio->qtd_itens); ?></td>

        
         <td> <?php echo e('R$ '.number_format($acessorio->valor*$acessorio->qtd_itens, 2, ',', '.')); ?></td>
         </tr>

         <?php
            $total_acessorio = ($total_acessorio+$acessorio->valor*$acessorio->qtd_itens);
         ?>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
      </table>

        <?php
      $custo_produto = ($total_acessorio+$total_ingredientes);
      ?>


<table class="table">
    <thead class="bg-success">
      <tr>
        <th scope="col"> Valor Custo = 
           <?php echo e('R$ '.number_format($custo_produto, 2, ',', '.')); ?></th>
      
      </tr>
    </thead>
</table>

<table class="table">
    <thead class="bg-warning">
      <tr>
        <th scope="col"> Valor Venda = 
           <?php echo e('R$ '.number_format($custo_produto*2, 2, ',', '.')); ?></th>
      
      </tr>
    </thead>
</table>
    


 <br>



</div>
</body>
</html>














<?php /**PATH C:\xampp\htdocs\calculo\resources\views/viewLanches.blade.php ENDPATH**/ ?>