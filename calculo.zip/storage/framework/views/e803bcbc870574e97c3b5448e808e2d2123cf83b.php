<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <div class="container">
      <h1>ENTRADA DE INGREDIENTES</h1>
    <form method="post" action="<?php echo e(url('/cadastro/entrada')); ?>">
      <?php echo csrf_field(); ?>

      <div class="form-group">
        <label for="unidade_medida"><b>Ingredientes</b></label>
        <select class="form-control" id="ingrediente" name="ingrediente">

            <?php $__currentLoopData = $ingredientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingrediente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <option  value=<?php echo e($ingrediente->id); ?>><?php echo e($ingrediente->descricao); ?> - <?php echo e($ingrediente->unidMedida); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      
      <div class="form-group">
        <label for="unid_medida"><b>Unidade de Medida</b></label>
        <select class="form-control" id="unid_medida" name="unid_medida">

           <!--<option value="gr">GR</option>-->
           <option value="po">PORÇÃO</option>
          <option value="kg">KG</option>
          <option value="un">UNIDADE</option>
          <option value="lt">LITRO</option>
        </select>
        <small id="descricao" class="form-text text-muted">Informe aqui a unidade de medida que você comprou desse ingrediente <button type="button" class="btn btn-secondary" data-toggle="tooltip" data-placement="top" title="EX: Kilo (informe KG), Litro (informe Litro), Unidade (informe Unidade), Porção (informe Porção)">  ?
</button></small>
      </div>
    
           
      <div class="form-group">
          <label for="qtd"><b>Quantidade</b></label>
          <input type="TEXT" class="form-control" id="qtd" name="qtd">
          <small id="descricao" class="form-text text-muted">
            Informe aqui a quantidade que você comprou desse ingrediente <button type="button" class="btn btn-secondary" data-toggle="tooltip" data-placement="top" title="EX: 1KG (informe 1000), 1LT (informe 1000), 100GR (informe 100), 10UN (informe 10)">
  ?
</button> </small>
        </div>
      
        <div class="form-group">
          <label for="descricao"><b>Valor Total</b></label>
          <input type="text" class="form-control" id="valor_total" name="valor_total">
          <small id="descricao" class="form-text text-muted">Informe aqui o valor total que você pagou nesse ingrediente</small>
        </div>
         
        <button type="submit" class="btn btn-primary">Gravar</button>
        <a href="<?php echo e(url("/")); ?>"> <button type="button" class="btn btn-warning">Voltar</button></a>
  

      </form><br>

      <form method="post" action="<?php echo e(url('/pesquisa/entrada')); ?>">
        <?php echo csrf_field(); ?>
      <div>
     <h5> Data Inicial</h5>
      <input type="date" name="dt_inicial">
     
      <h5>Data Final</h5>
      <input type="date" name="dt_final">
      <button type="submit" class="btn btn-primary btn-sm">Pesquisar</button>
      </div>
      <br>
      <table class="table table-success table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Descrição</th>
            <th scope="col">Data</th>
            <th scope="col">Valor</th>
          </tr>
        </thead>
        <tbody>
          <?php
           $total=0;
           ?>   
      
          <?php if(isset($psq)): ?>
          <?php $__currentLoopData = $psq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $psqs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row"><?php echo e($psqs->id); ?></th>
            <td><?php echo e($psqs->descricao); ?></td>
          
            <td><?php echo e(\Carbon\Carbon::parse($psqs->data_compra)->format('d/m/Y')); ?></td>
            <td><?php echo e('R$ '.number_format($psqs->valor, 2, ',', '.')); ?></td>

              <?php
            $total = $total + $psqs->valor;
            ?>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
          <?php endif; ?>
              </tbody>
                   
   
      </table>
      <table class="table table-success table-striped">
        <thead>
          <tr>
            <th scope="col"></th>
            <th scope="col"></th>
            <th scope="col"></th>
            <th scope="col"></th>
            <th scope="col"></th>
            <th scope="col"></th>
            <th scope="col"></th>
            <th scope="col"></th>
            <th scope="col"></th>
            <th scope="col"></th>
            <th scope="col"></th>
            <th><h3>Total = <?php echo e('R$ '.number_format($total, 2, ',', '.')); ?></h3></th>
          </tr>
        </thead>
    
      </table>
      
      </form>
  
    </div>
</body>
</html>

<script>
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
</script>

<?php /**PATH C:\xampp\htdocs\calculo\resources\views/cadEntradaIngredienteView.blade.php ENDPATH**/ ?>